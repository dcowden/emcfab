/**********************************************************************
*                        Heater 3 Project
*
*                    Michael Pearce 26 March 2001
*
* Electronics Workshop, Chemistry Department, University of Canterbury
***********************************************************************
Processors Used: PIC12C672
***********************************************************************
Disclaimer:
The following code has been released so that someone may possibly find
something useful in them. The Author and the company he works for takes
no responsibilty for the use of this code or any damage that may be
caused by using part of all of this code.
***********************************************************************
COPYRIGHT:
The hardware and code in this section copyrighted and may NOT be used
for any unauthorized comercial application. This is provided as an
example only and parts of the code may be used in different applications.
***********************************************************************
Overview:
The Heater 3 project is used to control waterbath heaters and other
specialist temperature controlled equipment within the Chemistry Department.
This project combines the use of the 1-wire routines, serial routines, a
P.I.D (Proportioal, Integral, Derivative) calculation, ADC, and a interrupt
driven burst mode heater control.
It was designed as a crude temperature control to hold within +/-3 degrees
of the target, but after testing it actually holds to within +/-1 degree
most of the time.
The target temperature is set by a variable resistor that is sampled by
the ADC.
The current temperature is read from a Dallas DS1820 probe in 1/2 degree
resolution.
The Output power is calculated using a P.I.D calculation.
The Output power is controlled by using a zero cross driven interrupt
routine that turns the heater ON for 0 to 100 full cycles of the mains and
OFF for the remainder of each 100 cycles, giving a crude form of 0 to 100%
control of the heater.
The temperature and current heater status etc are sent out via serial - was
used for debugging - but is quite handy.
Safety features have been added to cut out the heater if it has been run at
100% and no temperature change has occured within a set time. This lack of
change would occur if the probe fails, is disconnected, or is not in the heated
liquid/material.


Here is a list of the files:
SCHEMATIC.JPG
HEATCTR2.S01
MAIN.C
1WIRE.C
DELAY.H
DELAY.C
CHECKSUM.C

*********************** SCHEMATIC.JPG *****************************
DESCRIPTION:
JPG Image of the Schematic

************************ HEATCTR2.S01 ******************************
DESCRIPTION:
Autotrax Schematic File (DOS Version)

*************************** MAIN.C ********************************
USES: 1wire.c, delay.h, delay.c, checksum.c

DESCRIPTION:
This is the main program that reads the Variable Resistor and
temperature probe, performs the calculation and outputs to the
heater and serial.
The serial routine is a crude inbuilt routine that does the job.

*************************** 1WIRE.C ********************************
USES: delay.h, delay.c

DESCRIPTION:
Initialises and performs 1-wire bus functions.
Basic functions include reset, read and write.
More complex functions include match rom and read rom.

*************************** DELAY.H ********************************
DESCRIPTION:
Modified delay routines (Origianlly from HT-PIC example)

*************************** DELAY.C ********************************
DESCRIPTION:
Modified delay routines (Origianlly from HT-PIC example)

************************* CHECKSUM.C *******************************
DESCRIPTION:
This is the memory hungry CRC Check routine, but it works.
This is slightly modified from the code David Hayward used for a PC
version. It has a 256 byte table that allows a fast calculation
of the CRC, and it works.


********************************************************************/













