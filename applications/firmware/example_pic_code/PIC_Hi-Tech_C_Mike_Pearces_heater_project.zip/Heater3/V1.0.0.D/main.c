//*************************************************************************
//                      Heater Controller
//                        Version 1.0.0
//                       3 November 2000
//
// Info: A PIC12c6xx Based Heater Controller that uses a single DS1820
//       temperature probe and a simple P.I.D calculation and Full Wave
//       Pulsed output via Triac.
//
// Author: Michael Pearce
//         Chemistry Department, University Of Canterbury
//
// Started: 3 November 2000
//
//*************************************************************************
//                     VERSION INFORMATION
//*************************************************************************
// Version 1.0.0 - 3 November 2000
//   Got the Basics working, operates quite well, when settles has a
//   +/- 1 degree swing (or less). 
//*************************************************************************

#define XTAL_FREQ 4MHZ

#include <pic.h>

#define P_GAIN 4
#define D_GAIN 4
#define I_GAIN 2

#define I_COUNT_MAX   2            //-- # of intervals before increasing I
#define I_COUNT_DEC   4            //-- # times longer to wait b4 decrementing
#define I_VALUE_MAX   40           //-- Max Integral Value - Limits overshoot


#define CONTROLED_BAND 15          //-- Temperature band around Target that
                                   //   is controlled (2 units per degree!!)

#define MAX_TEMP    (89 * 2)       //-- Max Temperature of 89 Degrees
#define POT_DIVIDER 3              //-- Divide the Pots Value to get temp range
#define POT_SHIFT   5              //-- Shift up by this num of degrees
                                   //-- Note: Value is multiplied by 2 in the
                                   //   function to get 1/2 Degree resolution.


#define BURST_TOTAL_RELOAD 100         //-- Number of cycles per Run
#define BURST_PERCENT_DIVIDER 1        //-- Amount to div POWER to get count
#define BURST_TIMER_RELOAD  (-2)       //-- 2 counts per Full Wave
#define BURST_POWER_ON 100             //-- MAX POWER SETTING
#define BURST_POWER_OFF  0             //-- MIN POWER SETTING

#define OUTPUT_ON 0
#define OUTPUT_OFF 1


#ifndef BITNUM
 #define BITNUM(adr, bit)       ((unsigned)(&adr)*8+(bit))
#endif


//*********************** Ports ******************************
static bit POTINPUT      @ BITNUM(GPIO,0);   // POT input to ADC
static bit T_POTINPUT    @ BITNUM(TRIS,0);   // The tris for above

static bit PROBEINPUT    @ BITNUM(GPIO,1);   // PROBE INPUT - Dig &/or Analog
static bit T_PROBEINPUT  @ BITNUM(TRIS,1);   // The tris for above
#define D_PIN  PROBEINPUT
#define D_TRIS T_PROBEINPUT


static bit ZEROCROSSIN   @ BITNUM(GPIO,2);   // INPUT to Timer 4 Zero Cross
static bit T_ZEROCROSSIN @ BITNUM(TRIS,2);   // The tris for above


static bit RS232_RX      @ BITNUM(GPIO,3);   // RS232 Recieve Pin
static bit T_RS232_RX    @ BITNUM(TRIS,3);   // The tris for above

static bit OUTPUT_PIN    @ BITNUM(GPIO,4);   // OUTPUT to the TRIAC
static bit T_OUTPUT_PIN  @ BITNUM(TRIS,4);   // The tris for above


static bit RS232_TX      @ BITNUM(GPIO,5);   // RS232 Transmit Pin
static bit T_RS232_TX    @ BITNUM(TRIS,5);   // The tris for above


#include "delay.c"
#include "1wire.c"

#include "checksum.c"




// VARIABLES

 unsigned char BURST_ON_NEXT;            //-- Reload value for _COUNT
 unsigned char BURST_ON_COUNT;           //-- Number of counts to be ON
 unsigned char BURST_TOTAL_COUNT;        //-- Total number of Counts to do
 unsigned char BURST_PREVIOUS_SETTING;   //-- the previous power setting


 unsigned char Intergral;
 unsigned char I_Counter;

//******* FUNCTIONS ***********
unsigned char ReadADC(void);
void SendNum(unsigned char num);
void MM_ctoa(unsigned char val, char *str);
void RS232_Send(char *Data);
unsigned char Calculate(unsigned char TARGET,unsigned char CURRENT);
void Burst_Output (unsigned char Percentage);
unsigned char ReadProbe(unsigned char OldCurrent);



char Str_Target[]={"\rTarget:"};
char Str_Current[]="Current:";
char Str_Power[]="Power%:";

//*******************************************
void main (void)
{
 unsigned char target,current,power;
 OPTION=0x3F;

 TRIS=0xFF;
 GPIO=0xFF;

 //****** Initialise ports **********
 POTINPUT=1;
 T_POTINPUT=1;
 PROBEINPUT=1;
 T_PROBEINPUT=1;
 OUTPUT_PIN=1;
 T_OUTPUT_PIN=1;
 ZEROCROSSIN=1;
 T_ZEROCROSSIN=1;
 RS232_TX=1;
 T_RS232_TX=1;
 RS232_RX=1;
 T_RS232_RX=1;
 GPPU=1;   //-- Disable pull ups - all pins that would use it don't need it!
 ADCON1=0b00000110;    //-- GPIO.0 is the only Analog Input by Default
 ADCON0=0b00000001;  //-- Fastest sample rate - Turn ADC ON


 //****** Initialise Variables ***********
 BURST_ON_NEXT=0;                      //-- Reload value for _COUNT
 BURST_ON_COUNT=0;                     //-- Number of counts to be ON
 BURST_TOTAL_COUNT=BURST_TOTAL_RELOAD; //-- Total number of Counts to do
 BURST_PREVIOUS_SETTING=0;             //-- the previous power setting
 Intergral = 0;

 //****** Enable Interrupts ********
 INTCON=0x00;
 T0IE=1;
 GIE=1;


 //******* MAIN LOOP ********
 while(1)
 {
  target=ReadADC();


  current=ReadProbe(current);


  power=Calculate(target,current);

  Burst_Output(power);


  RS232_Send(Str_Target);
  SendNum(target/2);
  RS232_Send(Str_Current);
  SendNum(current/2);
  RS232_Send(Str_Power);
  SendNum(power);
 }
}

//*******************************************
unsigned char ReadADC(void)
{
 unsigned char temp;
 CHS1=0;            //-- Select Channel 0
 CHS0=0;
 ADON=1;            //-- Turn the ADC on
 CLRWDT();          //-- Clear the Watch Dog to allow time to convert b4 reset
 GODONE=1;          //-- Start the Conversion
 while(GODONE);     //-- Wait for Conversion to complete


 temp=((ADRES/POT_DIVIDER)+POT_SHIFT) * 2;  //-- Calculate the Range

 return(temp);
}
//*******************************************

void SendNum(unsigned char num)
{
 char string[5];
 MM_ctoa(num, string);
 RS232_Send(string);
}



//***************************************************************************
//                     MM_ctoa
//
// char to Ascii - Base 10 Conversion only
//***************************************************************************
void MM_ctoa(unsigned char val, char *str)
{
 signed char tmp;

 tmp=val/100;
 *str=tmp+'0';
 str++;
 val-=(tmp*100);

 tmp=val/10;
 *str=tmp+'0';
 str++;
 val-=(tmp*10);

 tmp=val;
 *str=tmp+'0';
 str++;
 *str=' ';              //-- Space

 str++;
 *str=0;                //-- Null Pointer

}

//**********************************************************************
unsigned char ReadProbe(unsigned char OldCurrent)
{
 unsigned char DATA[8],CRC,count;

 D_Reset();          //-- Reset Bus
 D_Write(0xCC);      //-- Skip Rom

 D_Write(0x44);      //-- Convert temperature

 DelayMs(200);       //-- Time To convert the temperature
 DelayMs(200);
 DelayMs(200);

 D_Reset();

  //-- Read in the data
 D_Write(0xCC);       //-- Skip Rom
 D_Write(0xBE);       //-- Read Scratch pad

 for(count=0;count<8;count++)
 {
  DATA[count]=D_Read();
 }
 CRC=D_Read();

 if( CRC == PROBE_CHECKSUM(DATA,sizeof(DATA)) )
 {
  if(DATA[1]==0)        //-- Check for a negative Flag
  {
   return(DATA[0]);     //-- If not Negative return the Value
  }
  else
  {
   return(0);           //-- If negative then return 0
  }
 }
 return(OldCurrent);
}
//******************** End of Read Probe *********************



//***************************************

#define	XTAL	4000000
#define	BRATE	9600
#define	DLY		3		/* cycles per null loop */
#define	TX_OHEAD	13		/* overhead cycles per loop */
#define	RX_OHEAD	12		/* receiver overhead per loop */

#define	DELAY(ohead)	(((XTAL/4/BRATE)-(ohead))/DLY)


void RS232_Send(char *Data)

{
 unsigned char	dly, bitno;
 char c;


 while(*Data !=0)                  //-- Send data till Null is found
 {
  c=*Data;
  bitno = 11;

  RS232_TX=1;                       //-- Ensure Data High to start with
  T_RS232_TX=0;                     //-- Ensure data is in output mode

  RS232_TX = 0;			/* start bit */
  bitno = 12;
  do
  {
  	dly = DELAY(TX_OHEAD);	/* wait one bit time */
  	do
   /* nix */ ;
	while(--dly);
	if(c & 1)
   {
	 RS232_TX = 1;
   }
   else
   {
	 RS232_TX = 0;
   }
	c = (c >> 1) | 0x80;
  } while(--bitno);
  Data++;                          //-- Point to next data byte
 }
}



//*******************
unsigned char Calculate(unsigned char TARGET,unsigned char CURRENT)
{
 unsigned char POWER;

 if(TARGET >= CURRENT)
 {
  if(CURRENT < (TARGET-CONTROLED_BAND))
  {
   POWER=100;
   Intergral=0;
  }
  else
  {
   if(CURRENT != TARGET)
   {
    if(I_Counter++ > I_COUNT_MAX)
    {
     I_Counter=0;        //-- Counter slows the response of I
     Intergral++;        //-- Only Increase Integral if less than target
     if(Intergral > I_VALUE_MAX) Intergral=I_VALUE_MAX;
    }
   }
   //-- P.I.D     Proportional                Integral                 Derivative
   POWER=((TARGET / CURRENT) * P_GAIN) + (Intergral * I_GAIN) + ((TARGET - CURRENT) * D_GAIN) ;
  }
 }
 else
 {
  POWER=0;
  if(I_Counter++ > (I_COUNT_MAX*I_COUNT_DEC))  //-- Slower decrease of value
  {
   I_Counter=0;        //-- Counter slows the response of I
   if(Intergral !=0)Intergral--;
  }
 }

 if(POWER > 100) POWER =100;

 if(CURRENT > MAX_TEMP) POWER=0;

 return(POWER);
}




//**********************************************************
void Burst_Output (unsigned char Percentage)
{

 if(Percentage != BURST_PREVIOUS_SETTING)      //-- Check if need to change
 {
  BURST_PREVIOUS_SETTING=Percentage;           //-- Need to change so store
  BURST_ON_NEXT=Percentage/BURST_PERCENT_DIVIDER; // All of the new settings

  if(BURST_ON_NEXT > BURST_TOTAL_RELOAD)     //-- Check if in limit
  {
   BURST_ON_NEXT = BURST_TOTAL_RELOAD;       //-- else set to the limit
  }
 }
}

//**********************************************************
void interrupt MyInterruptRoutine(void)
{
 GIE=0;
 //-- Timer 0 Overflow -- Used for zero cross detection
 if(T0IF)
 {
  T0IF=0;
  TMR0=BURST_TIMER_RELOAD;          //-- Reload timer for Net Wave Trigger

  if(BURST_ON_COUNT!=0)             //-- Check if need to Enable Output
  {
   BURST_ON_COUNT--;                //-- If so Decrement count by one
   T_OUTPUT_PIN=0;                  //-- Ensure TRIS set to OUTPUT
   OUTPUT_PIN=OUTPUT_ON;            //-- and enable the output
  }
  else
  {
   OUTPUT_PIN=OUTPUT_OFF;          //-- Else disable the output
  }

  BURST_TOTAL_COUNT--;             //-- Decrement the total count
  if(BURST_TOTAL_COUNT==0)         //-- Check if time is up
  {
   BURST_TOTAL_COUNT=BURST_TOTAL_RELOAD; //-- if so relead the total count
   BURST_ON_COUNT=BURST_ON_NEXT;   //-- and reload the NEXT ON count
  }

 }
 GIE=1;
}

